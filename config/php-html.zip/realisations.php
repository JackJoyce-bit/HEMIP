<?php
if (!function_exists('asset')) { function asset($p) { $f = __DIR__ . '/' . $p; return $p . '?v=' . (is_file($f) ? filemtime($f) : '1'); } }

session_start();

require_once "connexion.php";

/* =========================================================
   ADMIN
   ========================================================= */

$adminConnecte =
    isset($_SESSION['admin_connecte']) &&
    $_SESSION['admin_connecte'] === true;

$messageSucces = '';
$messageErreur = '';

$message = "";
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <meta name="description" content="Découvrir l’essai de valorisation des os de bétail présenté dans le dossier de HEMIP.">
    <meta name="theme-color" content="#1094d7">
    <meta name="application-name" content="HEMIP">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <meta name="apple-mobile-web-app-title" content="HEMIP">
    <script>window.addEventListener("beforeinstallprompt",function(e){e.preventDefault();window.__hemipInstallPrompt=e;});</script>
    <link rel="manifest" href="manifest.json" crossorigin="use-credentials">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/icons/hemip-180.png">
    <link rel="icon" type="image/png" sizes="192x192" href="assets/icons/hemip-192.png">
    <link rel="stylesheet" href="<?= asset('assets/vendor/remixicon/remixicon.css') ?>">
    <link rel="stylesheet" href="<?= asset('assets/css/style.css') ?>">
    <link rel="stylesheet" href="<?= asset('assets/css/pwa.css') ?>">
    <link rel="stylesheet" href="<?= asset('assets/css/independent-pages.css') ?>">
    <title>Nos réalisations | HEMIP</title>
  <link rel="stylesheet" href="<?= asset('assets/css/hemip-theme.css') ?>">
    <link rel="stylesheet" href="<?= asset('assets/css/responsive.css') ?>">
</head>
<body>
<header class="header">
    <nav class="navbar" aria-label="Navigation principale">
        <a href="index.php" class="logo"><img src="assets/img/logo-hemip.jpg" alt="Logo HEMIP"><span>HEMIP</span></a>
        <button class="menu-btn" id="menu-btn" type="button" aria-label="Ouvrir le menu de navigation" aria-expanded="false" aria-controls="nav-list"><span aria-hidden="true">☰</span></button>
        <ul class="nav-list" id="nav-list">
            <li><a href="index.php">Accueil</a></li>
            <li class="dropdown" id="formations">
                <button class="dropdown-btn" type="button" aria-expanded="false">Formation <i class="ri-arrow-down-s-line" aria-hidden="true"></i></button>
                <ul class="dropdown-menu">
                    <li class="submenu"><button class="submenu-btn" type="button">Pôle technique <i class="ri-arrow-right-s-line" aria-hidden="true"></i></button><ul class="submenu-menu">
                        <li><a href="GP.html">Génie Pétrolier</a></li><li><a href="GL.html">Génie Logiciel</a></li><li><a href="RT.html">Réseaux et Télécommunication</a></li><li><a href="MI.html">Maintenance Industrielle</a></li><li><a href="AII.html">Automatisation et Informatique Industriel</a></li>
                    </ul></li>
                    <li class="submenu"><button class="submenu-btn" type="button">Pôle Commercial <i class="ri-arrow-right-s-line" aria-hidden="true"></i></button><ul class="submenu-menu">
                        <li><a href="DAE.html">Droit des Affaires et des Entreprises</a></li><li><a href="GLT.html">Gestion Logistique et Transport</a></li><li><a href="BFA.html">Banque et Finance des Assurances</a></li><li><a href="CIT.html">Commerce International et Transit</a></li><li><a href="GFC.html">Gestion Finance et Comptable</a></li><li><a href="MRH.html">Management des Ressources Humaines</a></li>
                    </ul></li>
                </ul>
            </li>
            <li><a href="inscription.php">Inscription</a></li>
            <li><a href="actualite.php">Actualité</a></li>
            <li><a href="realisations.php" aria-current="page">Nos réalisations</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li><a href="a-propos.php">À propos</a></li>

            <!-- ADMIN -->

            <?php if ($adminConnecte): ?>

            <!-- Accès au tableau de bord -->
            <li>
                <a href="dashboard.php" title="Tableau de bord">
                    <i class="ri-dashboard-line"></i>
                </a>
            </li>

            <!-- Administrateur connecté -->
            <li class="admin-status">
                <i class="ri-admin-line" style="color: var(--hemip-bg);"></i>
                <span style="color: var(--hemip-bg); font-size: 15px;">Connecté</span>
            </li>

           <?php else: ?>

            <!-- Connexion administrateur -->
            <li>
                <a href="login.php" title="Connexion administrateur">
                    <i class="ri-admin-line"></i>
                </a>
            </li>

           <?php endif; ?>
            
        </ul>
    </nav>
</header>
<main class="achievement-page">
    <section class="independent-page-hero" aria-labelledby="achievement-page-title">
        <div class="independent-page-hero-inner">
            <div>
                <p class="independent-page-eyebrow">Recherche · Innovation · Matériaux écologiques</p>
                <h1 id="achievement-page-title">Valorisation expérimentale des os de bétail</h1>
                <p>Un essai présenté dans le dossier HEMIP explore la transformation de résidus osseux en poudre, avec pour objectif la recherche d’un matériau pouvant se substituer à la chaux vive.</p>
            </div>
            <div class="achievement-status"><i class="ri-flask-line" aria-hidden="true"></i><span>Essai expérimental<br><strong>Résultats d’un lot décrits dans le dossier</strong></span></div>
        </div>
    </section>

    <section class="achievement-section" aria-labelledby="achievement-results-title">
        <div class="achievement-wrap">
            <div class="achievement-heading">
                <p class="independent-page-eyebrow">Un résultat mesuré</p>
                <h2 id="achievement-results-title">Du lot d’os à la poudre finale</h2>
                <p>Le bilan expérimental documente le traitement d’un lot d’os frais, puis le refroidissement et le broyage du matériau obtenu.</p>
            </div>
            <div class="achievement-metrics" aria-label="Chiffres du lot expérimental">
                <article class="achievement-metric"><span>Charge de départ</span><strong>25 <small>kg</small></strong><p>Os frais mis en traitement.</p></article>
                <article class="achievement-metric"><span>Produit récupéré</span><strong>10 <small>kg</small></strong><p>Poudre finale après traitement et broyage.</p></article>
                <article class="achievement-metric achievement-metric--accent"><span>Rendement moyen indiqué</span><strong>56<small>%</small></strong><p>Production de CaO à partir de l’hydroxyapatite, selon le dossier.</p></article>
            </div>

            <div class="achievement-process" aria-label="Étapes décrites dans le dossier">
                <article><span class="achievement-step-number">01</span><div><h3>Traitement thermique</h3><p>Le lot d’os est soumis au traitement thermique décrit dans le bilan expérimental.</p></div></article>
                <article><span class="achievement-step-number">02</span><div><h3>Refroidissement</h3><p>Le matériau obtenu est refroidi avant les opérations de finition.</p></div></article>
                <article><span class="achievement-step-number">03</span><div><h3>Broyage et récupération</h3><p>Le matériau est broyé ; le dossier rapporte 10 kg de poudre finale pour ce lot.</p></div></article>
            </div>

            <aside class="achievement-caveat" aria-label="Précision sur le statut du projet">
                <i class="ri-information-line" aria-hidden="true"></i>
                <p><strong>À retenir :</strong> le document présente un essai et un objectif de recherche : étudier un matériau de substitution à la chaux vive pour le génie civil et d’autres applications industrielles. Il ne décrit pas une production industrielle ou une adoption commerciale déjà déployée.</p>
            </aside>
            <p class="achievement-source">Source : dossier de présentation HEMIP, pages 19–20.</p>
            <a class="btn btn-primary achievement-contact-link" href="contact.php">Contacter l’école <i class="ri-arrow-right-line" aria-hidden="true"></i></a>
        </div>
    </section>
    <section class="achievement-video-section" id="videos" aria-labelledby="achievement-videos-title">
        <div class="achievement-wrap">
            <div class="achievement-video-heading">
                <p class="independent-page-eyebrow">La vie à HEMIP</p>
                <h2 id="achievement-videos-title">Nos réalisations en vidéo</h2>
                <p>Visionnez ces vidéos directement sur le site, sans ouvrir une page YouTube. Une connexion Internet est nécessaire.</p>
            </div>
            <div class="achievement-video-grid">
                <article class="achievement-video-card">
                    <div class="achievement-video-frame"><iframe src="https://www.youtube-nocookie.com/embed/r8PUhZ3Lk7o" title="Média3 | vidéo HEMIP" loading="lazy" referrerpolicy="strict-origin-when-cross-origin" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></div>
                    <div class="achievement-video-caption"><span>Vidéo HEMIP</span><h3>Média3</h3></div>
                </article>
                <article class="achievement-video-card">
                    <div class="achievement-video-frame"><iframe src="https://www.youtube-nocookie.com/embed/qV1I03v1BJw" title="Média2 | vidéo HEMIP" loading="lazy" referrerpolicy="strict-origin-when-cross-origin" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></div>
                    <div class="achievement-video-caption"><span>Vidéo HEMIP</span><h3>Média2</h3></div>
                </article>
                <article class="achievement-video-card">
                    <div class="achievement-video-frame"><iframe src="https://www.youtube-nocookie.com/embed/zxi7epX-p0s" title="Média1 | vidéo HEMIP" loading="lazy" referrerpolicy="strict-origin-when-cross-origin" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></div>
                    <div class="achievement-video-caption"><span>Vidéo HEMIP</span><h3>Média1</h3></div>
                </article>
            </div>
            <p class="achievement-video-note">Lecteur intégré en mode de confidentialité avancé. Aucune redirection vers YouTube n’est nécessaire pour lancer une lecture autorisée.</p>
        </div>
    </section>
</main>
<footer class="footer reveal">
    <div class="footer-container " id="footer">

        <!-- Présentation -->
        <div class="footer-col footer-about">
            <div class="footer-logo">
                <img src="assets/img/logo-hemip.jpg" alt="Logo HEMIP">
                <span>HEMIP</span>
            </div>

            <p class="footer-slogan">
                « Nous formons des professionnels qualifiés et chevronnés »
            </p>
        </div>

        <!-- Contact -->
        <div class="footer-col">
            <h3>Contactez-nous</h3>

            <ul class="footer-contact">
                <li>
                    <i class="ri-mail-line"></i>
                    <a href="mailto:hemilaperceeinformation@gmail.com">
             hemilaperceeinformation@gmail.com
                    </a>
                </li>

                <li>
                    <i class="ri-phone-line"></i>
                    <a href="tel:+242069149242">
                        +242 06 914 92 42
                    </a>
                </li>

                <li>
                    <i class="ri-phone-line"></i>
                    <a href="tel:+242063560677">
                        +242 06 356 06 77
                    </a>
                </li>

            </ul>
        </div>

        <!-- Réseaux sociaux -->
        <div class="footer-col">
            <h3>Suivez-nous</h3>

            <p class="social-text">
                Retrouvez HEMIP sur nos réseaux sociaux.
            </p>

            <div class="social-links">

                <a href="https://vm.tiktok.com/ZS9kFSarLrbTD-96s9G/" class="social-link" aria-label="TikTok">
                    <i class="ri-tiktok-line"></i>
                </a>

                <a href="https://www.facebook.com/hemipcongo" class="social-link" aria-label="Facebook">
                    <i class="ri-facebook-fill"></i>
                </a>

                <a href="https://wa.me/242055865094"
                   class="social-link"
                   aria-label="WhatsApp"
                   target="_blank">
                    <i class="ri-whatsapp-line"></i>
                </a>

            </div>
        </div>

    </div>

    <!-- Bas du footer -->
    <div class="footer-bottom">
        <p>
            © 2026 HEMIP. Tous droits réservés.
        </p>

        <p>
            Haute École de Management et d'Ingénierie la Percée
        </p>
    </div>
</footer>
<script src="<?= asset('assets/js/main.js') ?>"></script>
<script src="<?= asset('assets/js/pwa.js') ?>" defer></script>
</body>
</html>
